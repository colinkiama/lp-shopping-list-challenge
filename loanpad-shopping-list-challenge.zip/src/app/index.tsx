import ShoppingList from "../views/ShoppingList";


export default function Index() {
  return (
    <ShoppingList />
  );
}
