export const Palette = {
    ACCENT_COLOR: '#539889',
    BUTTON_FOREGROUND_COLOR: '#ffffff',
    BRIM_BORDER_COLOR: '#d8d8d8',
    BRIM_BACKGROUND_COLOR: '#ffffff'
}